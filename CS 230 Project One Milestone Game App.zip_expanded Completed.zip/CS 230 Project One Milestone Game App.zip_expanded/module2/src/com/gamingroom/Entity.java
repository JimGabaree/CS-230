package com.gamingroom;

public class Entity {

	private long id;
	private String name;
	
private Entity() {
}	
public Entity(long id,String name){
    this();
    this.id=id;
    this.name=name;
}

long getId(){
    return (this.id);
}

String getName(){
    return (this.name);
}

@Override
public String toString() {

    return "Entity [id=" + id + ", name=" + name + "]";

}

// to test the entity to make sure it outputs correct information
public static void main(String[] args) {

    Entity test=new Entity(30,"Jim");

    System.out.println(test);

}
}
